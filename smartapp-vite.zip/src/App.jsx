
import { useState } from 'react';
import './index.css';
import aviator from './assets/aviator.png';
import mines from './assets/mines.png';
import penalties from './assets/penalties.png';
import logo from './assets/logo.png';

export default function App() {
  const [reviews] = useState([
    {
      name: "Anil Thapa",
      text: "Thanks to Smart App, I won big on Aviator! Truly amazing predictions!",
    },
    {
      name: "Sita Rana",
      text: "Smart App helped me double my wins on Mines. Highly recommend it!",
    },
    {
      name: "Bikash Gurung",
      text: "Penalties game was easy with Smart App tips. I'm a regular winner now!",
    },
  ]);

  return (
    <div className="min-h-screen p-6">
      <div className="max-w-4xl mx-auto space-y-6 text-white">
        <div className="text-center">
          <img src={logo} alt="Smart App Logo" width={120} className="mx-auto mb-4" />
          <h1 className="text-5xl font-bold">Smart App Predictor Bot</h1>
        </div>

        <p className="text-center text-lg">
          Created by <strong>Ravi Sherpa</strong> for Nepal. Earn by playing and referring friends!
        </p>

        <div className="flex justify-center gap-4">
          <button className="text-lg px-6 py-4 rounded-2xl shadow-lg bg-white text-black">
            <img src={aviator} alt="Aviator" width={24} className="inline-block mr-2" />
            Aviator
          </button>
          <button className="text-lg px-6 py-4 rounded-2xl shadow-lg bg-white text-black">
            <img src={mines} alt="Mines" width={24} className="inline-block mr-2" />
            Mines
          </button>
          <button className="text-lg px-6 py-4 rounded-2xl shadow-lg bg-white text-black">
            <img src={penalties} alt="Penalties" width={24} className="inline-block mr-2" />
            Penalties
          </button>
        </div>

        <div className="bg-white text-black p-4 rounded-xl shadow-md">
          <h2 className="text-2xl font-bold mb-2">Terms of Use</h2>
          <ul className="list-disc pl-5 space-y-1">
            <li>You must be 18+ to use the Smart App bot.</li>
            <li>Use predictions responsibly. This is not a guaranteed income.</li>
            <li>Referrals earn bonuses based on your friends' activity.</li>
            <li>Respect all users. No spamming or abuse allowed.</li>
          </ul>
        </div>

        <div className="bg-white text-black p-4 rounded-xl shadow-md">
          <h2 className="text-2xl font-bold mb-2">Sign Up</h2>
          <form className="space-y-4">
            <div>
              <label htmlFor="email" className="block font-semibold">Email address</label>
              <input id="email" type="email" placeholder="you@example.com" className="mt-1 w-full p-2 border rounded" required />
            </div>
            <div>
              <label htmlFor="telegram" className="block font-semibold">Telegram Username</label>
              <input id="telegram" type="text" placeholder="@yourusername" className="mt-1 w-full p-2 border rounded" required />
            </div>
            <button type="submit" className="w-full bg-blue-600 text-white py-2 rounded shadow">Register</button>
          </form>
        </div>

        <div className="bg-black/50 p-4 rounded-xl shadow-inner">
          <h2 className="text-2xl font-bold mb-4 text-center">Winner Reviews</h2>
          <div className="grid gap-4">
            {reviews.map((review, idx) => (
              <div key={idx} className="bg-white text-black p-4 rounded">
                <p className="font-semibold">{review.name}</p>
                <p>{review.text}</p>
              </div>
            ))}
          </div>
        </div>

        <div className="text-center mt-6">
          <p>Refer your friends and win more! Your referral link:</p>
          <code className="bg-white text-red-600 px-3 py-1 rounded-xl inline-block mt-2">
            https://smartapp.ravi.nepal/referral?user=yourID
          </code>
        </div>

        <div className="text-center mt-6">
          <a
            href="https://t.me/smartappbot"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-block bg-blue-600 text-white px-6 py-3 rounded-full text-lg shadow-lg hover:bg-blue-700 transition"
          >
            Connect with Smart App on Telegram
          </a>
        </div>
      </div>
    </div>
  );
}
